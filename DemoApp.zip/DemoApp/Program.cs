﻿using System;
using System.Linq;

namespace DemoApp
{
    class Program
    {
        private string connectionString;

        SqlConnection connection = new SqlConnection();
        SqlCommand command;
        SqlDataReader reader = null;
       

        public Program(){

             connectionString = "Server=ken-lws-113;Database=TEST_DB;Trusted_Connection=True;MultipleActiveResultSets=true"; // replace ken-lws-113 with your machine name

            connection.ConnectionString = connectionString;

        }

        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3,2,4,5,6,1};
           
            // Console.WriteLine("Hello World!");

            //QUESTION ONE
            int[] result = RemoveDublicates(array);  // removes dublicates in an array



            //Console.WriteLine(result.ToString());

            //QUESTION 2
            try
            {
                UpdateEmployeeSalary();
            }
            finally
            {
            }

           

        }


        public static int[] RemoveDublicates( int [] array)
        {

            return array.Distinct().ToArray();
        }



        private  void UpdateEmployeeSalary()
        {
       
    

            int empId = 1;
            int newSalary = 15000;
            int oldSalary = 0;

            try
            {
                if (this.connection.State == ConnectionState.Closed)
                {
                    this.connection.Open();
                }

                if (this.connection.State == ConnectionState.Open)
                {
                    command = new SqlCommand("UpdateEmployeeSalary", connection);
                    command.Connection = connection;
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Clear();

                    command.Parameters.Add(new SqlParameter("@empId", empId));
                    command.Parameters.Add(new SqlParameter("@newSalary", newSalary));
                    command.Parameters.Add(new SqlParameter("@oldSalary", oldSalary));

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {

            }
            

        }


    }
}
